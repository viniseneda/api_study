These configuration setups will spin up additional Prometheus and Grafana containers, setup NGINX Plus expose prometheus metrics.

